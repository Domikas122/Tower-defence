#pragma once
#include <iostream>
#include <sstream>
#include <string>
using namespace std;

class Utility{
	public:
		static void getInt(int & n);
};