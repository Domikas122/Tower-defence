#include "MapObject.h"

//Nothing here since pure abstract
