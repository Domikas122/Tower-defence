#include "IObserver.h"


IObserver::IObserver()
{
}


IObserver::~IObserver()
{
}
