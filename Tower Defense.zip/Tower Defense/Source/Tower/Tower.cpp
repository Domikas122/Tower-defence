#include "Tower.h"

const double Tower::REFUND_RATIO = 0.3;